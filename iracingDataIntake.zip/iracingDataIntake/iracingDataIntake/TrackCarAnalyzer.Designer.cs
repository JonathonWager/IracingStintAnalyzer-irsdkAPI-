﻿namespace iracingDataIntake
{
    partial class TrackCarAnalyzer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TrackListBox = new System.Windows.Forms.ComboBox();
            this.CarsListBox = new System.Windows.Forms.ComboBox();
            this.RacePannel = new System.Windows.Forms.Panel();
            this.lblAvgTopSpeed = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lblAvgTrackTemp = new System.Windows.Forms.Label();
            this.lblAvgAirTemp = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblOffPaceRace = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblTotalRaceLaps = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblAvgRace = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblRaceLapNum = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.lblRaceFuelUse = new System.Windows.Forms.Label();
            this.lblRaceFuelLvl = new System.Windows.Forms.Label();
            this.lblRaceATemp = new System.Windows.Forms.Label();
            this.lblRaceTTemp = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblFastestRaceLap = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRaceTitle = new System.Windows.Forms.Label();
            this.pnlSessionStats = new System.Windows.Forms.Panel();
            this.lblTtlStints = new System.Windows.Forms.Label();
            this.lblRaceStints = new System.Windows.Forms.Label();
            this.lblQualStints = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblTtlSessions = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.QualPannel = new System.Windows.Forms.Panel();
            this.lblTopSpeedQual = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblAvgQATemp = new System.Windows.Forms.Label();
            this.lblAvgQTTemp = new System.Windows.Forms.Label();
            this.lblAvgQualLap = new System.Windows.Forms.Label();
            this.lblQualOffPace = new System.Windows.Forms.Label();
            this.lblTotalQualLaps = new System.Windows.Forms.Label();
            this.lblQualFuelUse = new System.Windows.Forms.Label();
            this.lblQualFuel = new System.Windows.Forms.Label();
            this.lblQualATemp = new System.Windows.Forms.Label();
            this.lblQualtTemp = new System.Windows.Forms.Label();
            this.lblQualLapNumber = new System.Windows.Forms.Label();
            this.lblFastestQualLap = new System.Windows.Forms.Label();
            this.btnBack = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.FuelPannel = new System.Windows.Forms.Panel();
            this.lbl100lAvg = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.lblAvgFuelUse = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.RacePannel.SuspendLayout();
            this.pnlSessionStats.SuspendLayout();
            this.QualPannel.SuspendLayout();
            this.FuelPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // TrackListBox
            // 
            this.TrackListBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TrackListBox.FormattingEnabled = true;
            this.TrackListBox.Location = new System.Drawing.Point(32, 56);
            this.TrackListBox.Margin = new System.Windows.Forms.Padding(4);
            this.TrackListBox.Name = "TrackListBox";
            this.TrackListBox.Size = new System.Drawing.Size(154, 29);
            this.TrackListBox.TabIndex = 0;
            this.TrackListBox.SelectedIndexChanged += new System.EventHandler(this.TrackListBox_SelectedIndexChanged);
            // 
            // CarsListBox
            // 
            this.CarsListBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CarsListBox.FormattingEnabled = true;
            this.CarsListBox.Location = new System.Drawing.Point(265, 56);
            this.CarsListBox.Margin = new System.Windows.Forms.Padding(4);
            this.CarsListBox.Name = "CarsListBox";
            this.CarsListBox.Size = new System.Drawing.Size(154, 29);
            this.CarsListBox.TabIndex = 1;
            this.CarsListBox.SelectedIndexChanged += new System.EventHandler(this.CarListBox_SelectedIndexChanged);
            // 
            // RacePannel
            // 
            this.RacePannel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.RacePannel.Controls.Add(this.lblAvgTopSpeed);
            this.RacePannel.Controls.Add(this.label35);
            this.RacePannel.Controls.Add(this.lblAvgTrackTemp);
            this.RacePannel.Controls.Add(this.lblAvgAirTemp);
            this.RacePannel.Controls.Add(this.label16);
            this.RacePannel.Controls.Add(this.label15);
            this.RacePannel.Controls.Add(this.lblOffPaceRace);
            this.RacePannel.Controls.Add(this.label14);
            this.RacePannel.Controls.Add(this.lblTotalRaceLaps);
            this.RacePannel.Controls.Add(this.label13);
            this.RacePannel.Controls.Add(this.lblAvgRace);
            this.RacePannel.Controls.Add(this.label12);
            this.RacePannel.Controls.Add(this.lblRaceLapNum);
            this.RacePannel.Controls.Add(this.label11);
            this.RacePannel.Controls.Add(this.lblRaceFuelUse);
            this.RacePannel.Controls.Add(this.lblRaceFuelLvl);
            this.RacePannel.Controls.Add(this.lblRaceATemp);
            this.RacePannel.Controls.Add(this.lblRaceTTemp);
            this.RacePannel.Controls.Add(this.label10);
            this.RacePannel.Controls.Add(this.label9);
            this.RacePannel.Controls.Add(this.label8);
            this.RacePannel.Controls.Add(this.label4);
            this.RacePannel.Controls.Add(this.lblFastestRaceLap);
            this.RacePannel.Controls.Add(this.label1);
            this.RacePannel.Controls.Add(this.lblRaceTitle);
            this.RacePannel.Location = new System.Drawing.Point(40, 165);
            this.RacePannel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.RacePannel.Name = "RacePannel";
            this.RacePannel.Size = new System.Drawing.Size(907, 230);
            this.RacePannel.TabIndex = 2;
            // 
            // lblAvgTopSpeed
            // 
            this.lblAvgTopSpeed.AutoSize = true;
            this.lblAvgTopSpeed.Location = new System.Drawing.Point(751, 170);
            this.lblAvgTopSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgTopSpeed.Name = "lblAvgTopSpeed";
            this.lblAvgTopSpeed.Size = new System.Drawing.Size(19, 21);
            this.lblAvgTopSpeed.TabIndex = 25;
            this.lblAvgTopSpeed.Text = "0";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label35.Location = new System.Drawing.Point(751, 129);
            this.label35.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(142, 21);
            this.label35.TabIndex = 24;
            this.label35.Text = "Average Top Speed";
            // 
            // lblAvgTrackTemp
            // 
            this.lblAvgTrackTemp.AutoSize = true;
            this.lblAvgTrackTemp.Location = new System.Drawing.Point(447, 170);
            this.lblAvgTrackTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgTrackTemp.Name = "lblAvgTrackTemp";
            this.lblAvgTrackTemp.Size = new System.Drawing.Size(19, 21);
            this.lblAvgTrackTemp.TabIndex = 22;
            this.lblAvgTrackTemp.Text = "0";
            // 
            // lblAvgAirTemp
            // 
            this.lblAvgAirTemp.AutoSize = true;
            this.lblAvgAirTemp.Location = new System.Drawing.Point(611, 170);
            this.lblAvgAirTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgAirTemp.Name = "lblAvgAirTemp";
            this.lblAvgAirTemp.Size = new System.Drawing.Size(19, 21);
            this.lblAvgAirTemp.TabIndex = 21;
            this.lblAvgAirTemp.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label16.Location = new System.Drawing.Point(447, 129);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(148, 21);
            this.label16.TabIndex = 20;
            this.label16.Text = "Average Track Temp";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label15.Location = new System.Drawing.Point(611, 129);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(132, 21);
            this.label15.TabIndex = 19;
            this.label15.Text = "Average Air Temp";
            // 
            // lblOffPaceRace
            // 
            this.lblOffPaceRace.AutoSize = true;
            this.lblOffPaceRace.Location = new System.Drawing.Point(159, 170);
            this.lblOffPaceRace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOffPaceRace.Name = "lblOffPaceRace";
            this.lblOffPaceRace.Size = new System.Drawing.Size(19, 21);
            this.lblOffPaceRace.TabIndex = 18;
            this.lblOffPaceRace.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(159, 129);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(103, 21);
            this.label14.TabIndex = 17;
            this.label14.Text = "Laps Off Pace";
            // 
            // lblTotalRaceLaps
            // 
            this.lblTotalRaceLaps.AutoSize = true;
            this.lblTotalRaceLaps.Location = new System.Drawing.Point(22, 170);
            this.lblTotalRaceLaps.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalRaceLaps.Name = "lblTotalRaceLaps";
            this.lblTotalRaceLaps.Size = new System.Drawing.Size(19, 21);
            this.lblTotalRaceLaps.TabIndex = 16;
            this.lblTotalRaceLaps.Text = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(15, 129);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(115, 21);
            this.label13.TabIndex = 15;
            this.label13.Text = "Total Race Laps";
            // 
            // lblAvgRace
            // 
            this.lblAvgRace.AutoSize = true;
            this.lblAvgRace.Location = new System.Drawing.Point(292, 170);
            this.lblAvgRace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgRace.Name = "lblAvgRace";
            this.lblAvgRace.Size = new System.Drawing.Size(19, 21);
            this.lblAvgRace.TabIndex = 14;
            this.lblAvgRace.Text = "0";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(292, 125);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 21);
            this.label12.TabIndex = 13;
            this.label12.Text = "Average Race Lap";
            // 
            // lblRaceLapNum
            // 
            this.lblRaceLapNum.AutoSize = true;
            this.lblRaceLapNum.Location = new System.Drawing.Point(187, 80);
            this.lblRaceLapNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceLapNum.Name = "lblRaceLapNum";
            this.lblRaceLapNum.Size = new System.Drawing.Size(19, 21);
            this.lblRaceLapNum.TabIndex = 12;
            this.lblRaceLapNum.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(186, 47);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(97, 21);
            this.label11.TabIndex = 11;
            this.label11.Text = "Lap Number";
            // 
            // lblRaceFuelUse
            // 
            this.lblRaceFuelUse.AutoSize = true;
            this.lblRaceFuelUse.Location = new System.Drawing.Point(742, 80);
            this.lblRaceFuelUse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceFuelUse.Name = "lblRaceFuelUse";
            this.lblRaceFuelUse.Size = new System.Drawing.Size(19, 21);
            this.lblRaceFuelUse.TabIndex = 10;
            this.lblRaceFuelUse.Text = "0";
            // 
            // lblRaceFuelLvl
            // 
            this.lblRaceFuelLvl.AutoSize = true;
            this.lblRaceFuelLvl.Location = new System.Drawing.Point(610, 80);
            this.lblRaceFuelLvl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceFuelLvl.Name = "lblRaceFuelLvl";
            this.lblRaceFuelLvl.Size = new System.Drawing.Size(19, 21);
            this.lblRaceFuelLvl.TabIndex = 9;
            this.lblRaceFuelLvl.Text = "0";
            // 
            // lblRaceATemp
            // 
            this.lblRaceATemp.AutoSize = true;
            this.lblRaceATemp.Location = new System.Drawing.Point(490, 80);
            this.lblRaceATemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceATemp.Name = "lblRaceATemp";
            this.lblRaceATemp.Size = new System.Drawing.Size(19, 21);
            this.lblRaceATemp.TabIndex = 8;
            this.lblRaceATemp.Text = "0";
            // 
            // lblRaceTTemp
            // 
            this.lblRaceTTemp.AutoSize = true;
            this.lblRaceTTemp.Location = new System.Drawing.Point(338, 80);
            this.lblRaceTTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceTTemp.Name = "lblRaceTTemp";
            this.lblRaceTTemp.Size = new System.Drawing.Size(19, 21);
            this.lblRaceTTemp.TabIndex = 7;
            this.lblRaceTTemp.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(741, 47);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 21);
            this.label10.TabIndex = 6;
            this.label10.Text = "Fuel Used";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(610, 47);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 21);
            this.label9.TabIndex = 5;
            this.label9.Text = "Fuel Level";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.Location = new System.Drawing.Point(489, 47);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 21);
            this.label8.TabIndex = 4;
            this.label8.Text = "Air Temp";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(337, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Track Temp";
            // 
            // lblFastestRaceLap
            // 
            this.lblFastestRaceLap.AutoSize = true;
            this.lblFastestRaceLap.Location = new System.Drawing.Point(22, 80);
            this.lblFastestRaceLap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFastestRaceLap.Name = "lblFastestRaceLap";
            this.lblFastestRaceLap.Size = new System.Drawing.Size(19, 21);
            this.lblFastestRaceLap.TabIndex = 2;
            this.lblFastestRaceLap.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(22, 47);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Fastest Race Lap";
            // 
            // lblRaceTitle
            // 
            this.lblRaceTitle.AutoSize = true;
            this.lblRaceTitle.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRaceTitle.Location = new System.Drawing.Point(418, 10);
            this.lblRaceTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceTitle.Name = "lblRaceTitle";
            this.lblRaceTitle.Size = new System.Drawing.Size(85, 21);
            this.lblRaceTitle.TabIndex = 0;
            this.lblRaceTitle.Text = "Race Stats";
            // 
            // pnlSessionStats
            // 
            this.pnlSessionStats.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSessionStats.Controls.Add(this.lblTtlStints);
            this.pnlSessionStats.Controls.Add(this.lblRaceStints);
            this.pnlSessionStats.Controls.Add(this.lblQualStints);
            this.pnlSessionStats.Controls.Add(this.label7);
            this.pnlSessionStats.Controls.Add(this.label6);
            this.pnlSessionStats.Controls.Add(this.label5);
            this.pnlSessionStats.Controls.Add(this.lblTtlSessions);
            this.pnlSessionStats.Controls.Add(this.label3);
            this.pnlSessionStats.Controls.Add(this.label2);
            this.pnlSessionStats.Location = new System.Drawing.Point(506, 12);
            this.pnlSessionStats.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlSessionStats.Name = "pnlSessionStats";
            this.pnlSessionStats.Size = new System.Drawing.Size(532, 119);
            this.pnlSessionStats.TabIndex = 3;
            // 
            // lblTtlStints
            // 
            this.lblTtlStints.AutoSize = true;
            this.lblTtlStints.Location = new System.Drawing.Point(188, 73);
            this.lblTtlStints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTtlStints.Name = "lblTtlStints";
            this.lblTtlStints.Size = new System.Drawing.Size(19, 21);
            this.lblTtlStints.TabIndex = 8;
            this.lblTtlStints.Text = "0";
            // 
            // lblRaceStints
            // 
            this.lblRaceStints.AutoSize = true;
            this.lblRaceStints.Location = new System.Drawing.Point(334, 73);
            this.lblRaceStints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRaceStints.Name = "lblRaceStints";
            this.lblRaceStints.Size = new System.Drawing.Size(19, 21);
            this.lblRaceStints.TabIndex = 7;
            this.lblRaceStints.Text = "0";
            // 
            // lblQualStints
            // 
            this.lblQualStints.AutoSize = true;
            this.lblQualStints.Location = new System.Drawing.Point(459, 73);
            this.lblQualStints.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualStints.Name = "lblQualStints";
            this.lblQualStints.Size = new System.Drawing.Size(19, 21);
            this.lblQualStints.TabIndex = 6;
            this.lblQualStints.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.Location = new System.Drawing.Point(427, 43);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 21);
            this.label7.TabIndex = 5;
            this.label7.Text = "Qual Stints";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(298, 43);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 21);
            this.label6.TabIndex = 4;
            this.label6.Text = "Race Stints";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(160, 43);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 21);
            this.label5.TabIndex = 3;
            this.label5.Text = "Total Stints";
            // 
            // lblTtlSessions
            // 
            this.lblTtlSessions.AutoSize = true;
            this.lblTtlSessions.Location = new System.Drawing.Point(58, 73);
            this.lblTtlSessions.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTtlSessions.Name = "lblTtlSessions";
            this.lblTtlSessions.Size = new System.Drawing.Size(19, 21);
            this.lblTtlSessions.TabIndex = 2;
            this.lblTtlSessions.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(23, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 21);
            this.label3.TabIndex = 1;
            this.label3.Text = "Total Sessions";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(207, 10);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Session Stats";
            // 
            // QualPannel
            // 
            this.QualPannel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.QualPannel.Controls.Add(this.lblTopSpeedQual);
            this.QualPannel.Controls.Add(this.label34);
            this.QualPannel.Controls.Add(this.label30);
            this.QualPannel.Controls.Add(this.label29);
            this.QualPannel.Controls.Add(this.label28);
            this.QualPannel.Controls.Add(this.label27);
            this.QualPannel.Controls.Add(this.label26);
            this.QualPannel.Controls.Add(this.label25);
            this.QualPannel.Controls.Add(this.label24);
            this.QualPannel.Controls.Add(this.label23);
            this.QualPannel.Controls.Add(this.label22);
            this.QualPannel.Controls.Add(this.label21);
            this.QualPannel.Controls.Add(this.label20);
            this.QualPannel.Controls.Add(this.label19);
            this.QualPannel.Controls.Add(this.lblAvgQATemp);
            this.QualPannel.Controls.Add(this.lblAvgQTTemp);
            this.QualPannel.Controls.Add(this.lblAvgQualLap);
            this.QualPannel.Controls.Add(this.lblQualOffPace);
            this.QualPannel.Controls.Add(this.lblTotalQualLaps);
            this.QualPannel.Controls.Add(this.lblQualFuelUse);
            this.QualPannel.Controls.Add(this.lblQualFuel);
            this.QualPannel.Controls.Add(this.lblQualATemp);
            this.QualPannel.Controls.Add(this.lblQualtTemp);
            this.QualPannel.Controls.Add(this.lblQualLapNumber);
            this.QualPannel.Controls.Add(this.lblFastestQualLap);
            this.QualPannel.Location = new System.Drawing.Point(40, 429);
            this.QualPannel.Margin = new System.Windows.Forms.Padding(4);
            this.QualPannel.Name = "QualPannel";
            this.QualPannel.Size = new System.Drawing.Size(907, 229);
            this.QualPannel.TabIndex = 4;
            // 
            // lblTopSpeedQual
            // 
            this.lblTopSpeedQual.AutoSize = true;
            this.lblTopSpeedQual.Location = new System.Drawing.Point(751, 170);
            this.lblTopSpeedQual.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTopSpeedQual.Name = "lblTopSpeedQual";
            this.lblTopSpeedQual.Size = new System.Drawing.Size(19, 21);
            this.lblTopSpeedQual.TabIndex = 24;
            this.lblTopSpeedQual.Text = "0";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label34.Location = new System.Drawing.Point(751, 126);
            this.label34.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(142, 21);
            this.label34.TabIndex = 23;
            this.label34.Text = "Average Top Speed";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label30.Location = new System.Drawing.Point(611, 126);
            this.label30.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(132, 21);
            this.label30.TabIndex = 22;
            this.label30.Text = "Average Air Temp";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label29.Location = new System.Drawing.Point(447, 126);
            this.label29.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(148, 21);
            this.label29.TabIndex = 21;
            this.label29.Text = "Average Track Temp";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label28.Location = new System.Drawing.Point(292, 126);
            this.label28.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(133, 21);
            this.label28.TabIndex = 20;
            this.label28.Text = "Average Qual Lap";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label27.Location = new System.Drawing.Point(159, 126);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 21);
            this.label27.TabIndex = 19;
            this.label27.Text = "Laps Off Pace";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label26.Location = new System.Drawing.Point(15, 126);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(115, 21);
            this.label26.TabIndex = 18;
            this.label26.Text = "Total Qual Laps";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label25.Location = new System.Drawing.Point(741, 48);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(78, 21);
            this.label25.TabIndex = 17;
            this.label25.Text = "Fuel Used";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label24.Location = new System.Drawing.Point(610, 48);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(79, 21);
            this.label24.TabIndex = 16;
            this.label24.Text = "Fuel Level";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label23.Location = new System.Drawing.Point(393, 10);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(124, 21);
            this.label23.TabIndex = 15;
            this.label23.Text = "Qualifying Stats";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label22.Location = new System.Drawing.Point(489, 48);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 21);
            this.label22.TabIndex = 14;
            this.label22.Text = "Air Temp";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label21.Location = new System.Drawing.Point(337, 48);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(87, 21);
            this.label21.TabIndex = 13;
            this.label21.Text = "Track Temp";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label20.Location = new System.Drawing.Point(187, 48);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 21);
            this.label20.TabIndex = 12;
            this.label20.Text = "Lap Number";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label19.Location = new System.Drawing.Point(22, 48);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(123, 21);
            this.label19.TabIndex = 11;
            this.label19.Text = "Fastest Qual Lap";
            // 
            // lblAvgQATemp
            // 
            this.lblAvgQATemp.AutoSize = true;
            this.lblAvgQATemp.Location = new System.Drawing.Point(611, 170);
            this.lblAvgQATemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgQATemp.Name = "lblAvgQATemp";
            this.lblAvgQATemp.Size = new System.Drawing.Size(19, 21);
            this.lblAvgQATemp.TabIndex = 10;
            this.lblAvgQATemp.Text = "0";
            // 
            // lblAvgQTTemp
            // 
            this.lblAvgQTTemp.AutoSize = true;
            this.lblAvgQTTemp.Location = new System.Drawing.Point(447, 170);
            this.lblAvgQTTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgQTTemp.Name = "lblAvgQTTemp";
            this.lblAvgQTTemp.Size = new System.Drawing.Size(19, 21);
            this.lblAvgQTTemp.TabIndex = 9;
            this.lblAvgQTTemp.Text = "0";
            // 
            // lblAvgQualLap
            // 
            this.lblAvgQualLap.AutoSize = true;
            this.lblAvgQualLap.Location = new System.Drawing.Point(292, 170);
            this.lblAvgQualLap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgQualLap.Name = "lblAvgQualLap";
            this.lblAvgQualLap.Size = new System.Drawing.Size(19, 21);
            this.lblAvgQualLap.TabIndex = 8;
            this.lblAvgQualLap.Text = "0";
            // 
            // lblQualOffPace
            // 
            this.lblQualOffPace.AutoSize = true;
            this.lblQualOffPace.Location = new System.Drawing.Point(159, 170);
            this.lblQualOffPace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualOffPace.Name = "lblQualOffPace";
            this.lblQualOffPace.Size = new System.Drawing.Size(19, 21);
            this.lblQualOffPace.TabIndex = 7;
            this.lblQualOffPace.Text = "0";
            // 
            // lblTotalQualLaps
            // 
            this.lblTotalQualLaps.AutoSize = true;
            this.lblTotalQualLaps.Location = new System.Drawing.Point(22, 170);
            this.lblTotalQualLaps.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTotalQualLaps.Name = "lblTotalQualLaps";
            this.lblTotalQualLaps.Size = new System.Drawing.Size(19, 21);
            this.lblTotalQualLaps.TabIndex = 6;
            this.lblTotalQualLaps.Text = "0";
            // 
            // lblQualFuelUse
            // 
            this.lblQualFuelUse.AutoSize = true;
            this.lblQualFuelUse.Location = new System.Drawing.Point(742, 82);
            this.lblQualFuelUse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualFuelUse.Name = "lblQualFuelUse";
            this.lblQualFuelUse.Size = new System.Drawing.Size(19, 21);
            this.lblQualFuelUse.TabIndex = 5;
            this.lblQualFuelUse.Text = "0";
            // 
            // lblQualFuel
            // 
            this.lblQualFuel.AutoSize = true;
            this.lblQualFuel.Location = new System.Drawing.Point(611, 82);
            this.lblQualFuel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualFuel.Name = "lblQualFuel";
            this.lblQualFuel.Size = new System.Drawing.Size(19, 21);
            this.lblQualFuel.TabIndex = 4;
            this.lblQualFuel.Text = "0";
            // 
            // lblQualATemp
            // 
            this.lblQualATemp.AutoSize = true;
            this.lblQualATemp.Location = new System.Drawing.Point(490, 82);
            this.lblQualATemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualATemp.Name = "lblQualATemp";
            this.lblQualATemp.Size = new System.Drawing.Size(19, 21);
            this.lblQualATemp.TabIndex = 3;
            this.lblQualATemp.Text = "0";
            // 
            // lblQualtTemp
            // 
            this.lblQualtTemp.AutoSize = true;
            this.lblQualtTemp.Location = new System.Drawing.Point(338, 82);
            this.lblQualtTemp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualtTemp.Name = "lblQualtTemp";
            this.lblQualtTemp.Size = new System.Drawing.Size(19, 21);
            this.lblQualtTemp.TabIndex = 2;
            this.lblQualtTemp.Text = "0";
            // 
            // lblQualLapNumber
            // 
            this.lblQualLapNumber.AutoSize = true;
            this.lblQualLapNumber.Location = new System.Drawing.Point(187, 82);
            this.lblQualLapNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblQualLapNumber.Name = "lblQualLapNumber";
            this.lblQualLapNumber.Size = new System.Drawing.Size(19, 21);
            this.lblQualLapNumber.TabIndex = 1;
            this.lblQualLapNumber.Text = "0";
            // 
            // lblFastestQualLap
            // 
            this.lblFastestQualLap.AutoSize = true;
            this.lblFastestQualLap.Location = new System.Drawing.Point(22, 82);
            this.lblFastestQualLap.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFastestQualLap.Name = "lblFastestQualLap";
            this.lblFastestQualLap.Size = new System.Drawing.Size(19, 21);
            this.lblFastestQualLap.TabIndex = 0;
            this.lblFastestQualLap.Text = "0";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(994, 149);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(96, 32);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label17.Location = new System.Drawing.Point(56, 23);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 20);
            this.label17.TabIndex = 6;
            this.label17.Text = "Select a Track";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label18.Location = new System.Drawing.Point(295, 23);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 20);
            this.label18.TabIndex = 7;
            this.label18.Text = "Select a Car";
            // 
            // FuelPannel
            // 
            this.FuelPannel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.FuelPannel.Controls.Add(this.lbl100lAvg);
            this.FuelPannel.Controls.Add(this.label33);
            this.FuelPannel.Controls.Add(this.lblAvgFuelUse);
            this.FuelPannel.Controls.Add(this.label32);
            this.FuelPannel.Controls.Add(this.label31);
            this.FuelPannel.Location = new System.Drawing.Point(966, 213);
            this.FuelPannel.Name = "FuelPannel";
            this.FuelPannel.Size = new System.Drawing.Size(161, 287);
            this.FuelPannel.TabIndex = 8;
            // 
            // lbl100lAvg
            // 
            this.lbl100lAvg.AutoSize = true;
            this.lbl100lAvg.Location = new System.Drawing.Point(60, 171);
            this.lbl100lAvg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl100lAvg.Name = "lbl100lAvg";
            this.lbl100lAvg.Size = new System.Drawing.Size(19, 21);
            this.lbl100lAvg.TabIndex = 5;
            this.lbl100lAvg.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label33.Location = new System.Drawing.Point(11, 138);
            this.label33.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(138, 21);
            this.label33.TabIndex = 4;
            this.label33.Text = "Laps on 100L Tank";
            // 
            // lblAvgFuelUse
            // 
            this.lblAvgFuelUse.AutoSize = true;
            this.lblAvgFuelUse.Location = new System.Drawing.Point(52, 81);
            this.lblAvgFuelUse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAvgFuelUse.Name = "lblAvgFuelUse";
            this.lblAvgFuelUse.Size = new System.Drawing.Size(19, 21);
            this.lblAvgFuelUse.TabIndex = 3;
            this.lblAvgFuelUse.Text = "0";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label32.Location = new System.Drawing.Point(6, 48);
            this.label32.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(147, 21);
            this.label32.TabIndex = 2;
            this.label32.Text = "Average Fuel Usage";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label31.Location = new System.Drawing.Point(35, 9);
            this.label31.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(79, 21);
            this.label31.TabIndex = 1;
            this.label31.Text = "Fuel Stats";
            // 
            // TrackCarAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1153, 686);
            this.Controls.Add(this.FuelPannel);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.QualPannel);
            this.Controls.Add(this.pnlSessionStats);
            this.Controls.Add(this.RacePannel);
            this.Controls.Add(this.CarsListBox);
            this.Controls.Add(this.TrackListBox);
            this.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TrackCarAnalyzer";
            this.Text = "TrackCarAnalyzer";
            this.RacePannel.ResumeLayout(false);
            this.RacePannel.PerformLayout();
            this.pnlSessionStats.ResumeLayout(false);
            this.pnlSessionStats.PerformLayout();
            this.QualPannel.ResumeLayout(false);
            this.QualPannel.PerformLayout();
            this.FuelPannel.ResumeLayout(false);
            this.FuelPannel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ComboBox TrackListBox;
        private ComboBox CarsListBox;
        private Panel RacePannel;
        private Label lblRaceTitle;
        private Label label1;
        private Panel pnlSessionStats;
        private Label label3;
        private Label label2;
        private Label lblTtlStints;
        private Label lblRaceStints;
        private Label lblQualStints;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label lblTtlSessions;
        private Label lblFastestRaceLap;
        private Label label4;
        private Label label8;
        private Label lblRaceFuelUse;
        private Label lblRaceFuelLvl;
        private Label lblRaceATemp;
        private Label lblRaceTTemp;
        private Label label10;
        private Label label9;
        private Label lblRaceLapNum;
        private Label label12;
        private Label lblAvgRace;
        private Label label13;
        private Label lblOffPaceRace;
        private Label label14;
        private Label lblTotalRaceLaps;
        private Label lblAvgTrackTemp;
        private Label lblAvgAirTemp;
        private Label label16;
        private Label label15;
        private Panel QualPannel;
        private Label lblFastestQualLap;
        private Button btnBack;
        private Label lblQualLapNumber;
        private Label lblQualFuelUse;
        private Label lblQualFuel;
        private Label lblQualATemp;
        private Label lblQualtTemp;
        private Label lblAvgQATemp;
        private Label lblAvgQTTemp;
        private Label lblAvgQualLap;
        private Label lblQualOffPace;
        private Label lblTotalQualLaps;
        private Label label17;
        private Label label18;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label11;
        private Panel FuelPannel;
        private Label label33;
        private Label lblAvgFuelUse;
        private Label label32;
        private Label label31;
        private Label lbl100lAvg;
        private Label lblAvgTopSpeed;
        private Label label35;
        private Label lblTopSpeedQual;
        private Label label34;
    }
}