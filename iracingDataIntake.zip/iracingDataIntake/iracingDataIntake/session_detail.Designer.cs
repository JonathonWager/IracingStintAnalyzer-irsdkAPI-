﻿namespace iracingDataIntake
{
    partial class session_detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StintView = new System.Windows.Forms.ListView();
            this.viewStint = new System.Windows.Forms.ColumnHeader();
            this.stintCount = new System.Windows.Forms.ColumnHeader();
            this.Time = new System.Windows.Forms.ColumnHeader();
            this.Type = new System.Windows.Forms.ColumnHeader();
            this.LapCount = new System.Windows.Forms.ColumnHeader();
            this.FastestLap = new System.Windows.Forms.ColumnHeader();
            this.startTime = new System.Windows.Forms.ColumnHeader();
            this.trackTemp = new System.Windows.Forms.ColumnHeader();
            this.airTemp = new System.Windows.Forms.ColumnHeader();
            this.fuel = new System.Windows.Forms.ColumnHeader();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // StintView
            // 
            this.StintView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.viewStint,
            this.stintCount,
            this.Time,
            this.Type,
            this.LapCount,
            this.FastestLap,
            this.startTime,
            this.trackTemp,
            this.airTemp,
            this.fuel});
            this.StintView.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.StintView.Location = new System.Drawing.Point(12, 12);
            this.StintView.Name = "StintView";
            this.StintView.Size = new System.Drawing.Size(812, 426);
            this.StintView.TabIndex = 0;
            this.StintView.UseCompatibleStateImageBehavior = false;
            this.StintView.View = System.Windows.Forms.View.Details;
            this.StintView.SelectedIndexChanged += new System.EventHandler(this.StintView_SelectedIndexChanged);
            // 
            // viewStint
            // 
            this.viewStint.Text = "View Stint";
            this.viewStint.Width = 80;
            // 
            // stintCount
            // 
            this.stintCount.Text = "Stint";
            this.stintCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.stintCount.Width = 50;
            // 
            // Time
            // 
            this.Time.Text = "Time";
            this.Time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Time.Width = 85;
            // 
            // Type
            // 
            this.Type.Text = "Stint Type";
            this.Type.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Type.Width = 80;
            // 
            // LapCount
            // 
            this.LapCount.Text = "Laps";
            this.LapCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LapCount.Width = 50;
            // 
            // FastestLap
            // 
            this.FastestLap.Text = "Fastest Lap";
            this.FastestLap.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.FastestLap.Width = 105;
            // 
            // startTime
            // 
            this.startTime.Text = "Session Time";
            this.startTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.startTime.Width = 100;
            // 
            // trackTemp
            // 
            this.trackTemp.Text = "Track Temp";
            this.trackTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.trackTemp.Width = 90;
            // 
            // airTemp
            // 
            this.airTemp.Text = "Air Temp";
            this.airTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.airTemp.Width = 90;
            // 
            // fuel
            // 
            this.fuel.Text = "Fuel";
            this.fuel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fuel.Width = 75;
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(855, 28);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 1;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // session_detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(954, 492);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.StintView);
            this.Name = "session_detail";
            this.Text = "Session";
            this.ResumeLayout(false);

        }

        #endregion

        private ListView StintView;
        private Button btnBack;
        private ColumnHeader Time;
        private ColumnHeader stintCount;
        private ColumnHeader Type;
        private ColumnHeader LapCount;
        private ColumnHeader FastestLap;
        private ColumnHeader startTime;
        private ColumnHeader trackTemp;
        private ColumnHeader airTemp;
        private ColumnHeader fuel;
        private ColumnHeader viewStint;
    }
}