﻿namespace iracingDataIntake
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sessions_view = new System.Windows.Forms.ListView();
            this.clicktoview = new System.Windows.Forms.ColumnHeader();
            this.Date = new System.Windows.Forms.ColumnHeader();
            this.Track = new System.Windows.Forms.ColumnHeader();
            this.Car = new System.Windows.Forms.ColumnHeader();
            this.Stints = new System.Windows.Forms.ColumnHeader();
            this.startTime = new System.Windows.Forms.ColumnHeader();
            this.startTrackTemp = new System.Windows.Forms.ColumnHeader();
            this.startAirTemp = new System.Windows.Forms.ColumnHeader();
            this.label1 = new System.Windows.Forms.Label();
            this.btnStartPy = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnAnalytics = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // sessions_view
            // 
            this.sessions_view.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clicktoview,
            this.Date,
            this.Track,
            this.Car,
            this.Stints,
            this.startTime,
            this.startTrackTemp,
            this.startAirTemp});
            this.sessions_view.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sessions_view.Location = new System.Drawing.Point(12, 47);
            this.sessions_view.Name = "sessions_view";
            this.sessions_view.Size = new System.Drawing.Size(1024, 576);
            this.sessions_view.TabIndex = 0;
            this.sessions_view.UseCompatibleStateImageBehavior = false;
            this.sessions_view.View = System.Windows.Forms.View.Details;
            this.sessions_view.SelectedIndexChanged += new System.EventHandler(this.sessions_view_SelectedIndexChanged);
            // 
            // clicktoview
            // 
            this.clicktoview.Text = "Veiw Session";
            this.clicktoview.Width = 100;
            // 
            // Date
            // 
            this.Date.Text = "Date";
            this.Date.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Date.Width = 165;
            // 
            // Track
            // 
            this.Track.Text = "Track";
            this.Track.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Track.Width = 182;
            // 
            // Car
            // 
            this.Car.Text = "Car";
            this.Car.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Car.Width = 182;
            // 
            // Stints
            // 
            this.Stints.Text = "Stint Count";
            this.Stints.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Stints.Width = 100;
            // 
            // startTime
            // 
            this.startTime.Text = "Session TIme";
            this.startTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.startTime.Width = 110;
            // 
            // startTrackTemp
            // 
            this.startTrackTemp.Text = "Track Temp";
            this.startTrackTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.startTrackTemp.Width = 90;
            // 
            // startAirTemp
            // 
            this.startAirTemp.Text = "Air Temp";
            this.startAirTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.startAirTemp.Width = 90;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Snow;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Recent Sessions";
            // 
            // btnStartPy
            // 
            this.btnStartPy.Location = new System.Drawing.Point(1089, 47);
            this.btnStartPy.Name = "btnStartPy";
            this.btnStartPy.Size = new System.Drawing.Size(136, 23);
            this.btnStartPy.TabIndex = 2;
            this.btnStartPy.Text = "Start Data Recoring";
            this.btnStartPy.UseVisualStyleBackColor = true;
            this.btnStartPy.Click += new System.EventHandler(this.btnStartPy_Click);
            // 
            // btnRefresh
            // 
            this.btnRefresh.Location = new System.Drawing.Point(1088, 204);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(136, 23);
            this.btnRefresh.TabIndex = 3;
            this.btnRefresh.Text = "Refresh Stints";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            // 
            // btnAnalytics
            // 
            this.btnAnalytics.Location = new System.Drawing.Point(1089, 122);
            this.btnAnalytics.Name = "btnAnalytics";
            this.btnAnalytics.Size = new System.Drawing.Size(135, 23);
            this.btnAnalytics.TabIndex = 4;
            this.btnAnalytics.Text = "Veiw Analytics";
            this.btnAnalytics.UseVisualStyleBackColor = true;
            this.btnAnalytics.Click += new System.EventHandler(this.btnAnalytics_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(1270, 650);
            this.Controls.Add(this.btnAnalytics);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnStartPy);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.sessions_view);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "ITracker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListView sessions_view;
        private Label label1;
        private Button btnStartPy;
        private Button btnRefresh;
        private ColumnHeader Date;
        private ColumnHeader Track;
        private ColumnHeader Car;
        private ColumnHeader Stints;
        private ColumnHeader startTime;
        private ColumnHeader startTrackTemp;
        private ColumnHeader startAirTemp;
        private Button btnAnalytics;
        private ColumnHeader clicktoview;
    }
}