﻿namespace iracingDataIntake
{
    partial class Stint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTrackName = new System.Windows.Forms.Label();
            this.lblTrackTemp = new System.Windows.Forms.Label();
            this.lblAirTemp = new System.Windows.Forms.Label();
            this.lblCarName = new System.Windows.Forms.Label();
            this.LapsView = new System.Windows.Forms.ListView();
            this.Lap = new System.Windows.Forms.ColumnHeader();
            this.laptime = new System.Windows.Forms.ColumnHeader();
            this.fuelrem = new System.Windows.Forms.ColumnHeader();
            this.fuelusage = new System.Windows.Forms.ColumnHeader();
            this.lapsrem = new System.Windows.Forms.ColumnHeader();
            this.topspeed = new System.Windows.Forms.ColumnHeader();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblFastest = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTrackName
            // 
            this.lblTrackName.AutoSize = true;
            this.lblTrackName.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTrackName.Location = new System.Drawing.Point(227, 48);
            this.lblTrackName.Name = "lblTrackName";
            this.lblTrackName.Size = new System.Drawing.Size(118, 25);
            this.lblTrackName.TabIndex = 0;
            this.lblTrackName.Text = "Laguna Seca";
            // 
            // lblTrackTemp
            // 
            this.lblTrackTemp.AutoSize = true;
            this.lblTrackTemp.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTrackTemp.Location = new System.Drawing.Point(435, 9);
            this.lblTrackTemp.Name = "lblTrackTemp";
            this.lblTrackTemp.Size = new System.Drawing.Size(109, 25);
            this.lblTrackTemp.TabIndex = 2;
            this.lblTrackTemp.Text = "Track Temp:";
            // 
            // lblAirTemp
            // 
            this.lblAirTemp.AutoSize = true;
            this.lblAirTemp.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAirTemp.Location = new System.Drawing.Point(454, 48);
            this.lblAirTemp.Name = "lblAirTemp";
            this.lblAirTemp.Size = new System.Drawing.Size(90, 25);
            this.lblAirTemp.TabIndex = 3;
            this.lblAirTemp.Text = "Air Temp:";
            // 
            // lblCarName
            // 
            this.lblCarName.AutoSize = true;
            this.lblCarName.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCarName.Location = new System.Drawing.Point(12, 48);
            this.lblCarName.Name = "lblCarName";
            this.lblCarName.Size = new System.Drawing.Size(111, 25);
            this.lblCarName.TabIndex = 7;
            this.lblCarName.Text = "Audi r8 Lms";
            // 
            // LapsView
            // 
            this.LapsView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Lap,
            this.laptime,
            this.fuelrem,
            this.fuelusage,
            this.lapsrem,
            this.topspeed});
            this.LapsView.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LapsView.Location = new System.Drawing.Point(12, 76);
            this.LapsView.Name = "LapsView";
            this.LapsView.Size = new System.Drawing.Size(604, 537);
            this.LapsView.TabIndex = 12;
            this.LapsView.UseCompatibleStateImageBehavior = false;
            this.LapsView.View = System.Windows.Forms.View.Details;
            // 
            // Lap
            // 
            this.Lap.Text = "Lap";
            this.Lap.Width = 40;
            // 
            // laptime
            // 
            this.laptime.Text = "Lap Time";
            this.laptime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.laptime.Width = 100;
            // 
            // fuelrem
            // 
            this.fuelrem.Text = "Fuel Remaining";
            this.fuelrem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fuelrem.Width = 120;
            // 
            // fuelusage
            // 
            this.fuelusage.Text = "Fuel Usage";
            this.fuelusage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.fuelusage.Width = 100;
            // 
            // lapsrem
            // 
            this.lapsrem.Text = "Laps Remaining";
            this.lapsrem.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.lapsrem.Width = 120;
            // 
            // topspeed
            // 
            this.topspeed.Text = "Top Speed";
            this.topspeed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.topspeed.Width = 115;
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblTime.Location = new System.Drawing.Point(12, 9);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(72, 25);
            this.lblTime.TabIndex = 13;
            this.lblTime.Text = "5:16am";
            // 
            // lblFastest
            // 
            this.lblFastest.AutoSize = true;
            this.lblFastest.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFastest.Location = new System.Drawing.Point(227, 9);
            this.lblFastest.Name = "lblFastest";
            this.lblFastest.Size = new System.Drawing.Size(112, 25);
            this.lblFastest.TabIndex = 14;
            this.lblFastest.Text = "Fastest Lap: ";
            // 
            // Stint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Snow;
            this.ClientSize = new System.Drawing.Size(625, 653);
            this.Controls.Add(this.lblFastest);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.LapsView);
            this.Controls.Add(this.lblCarName);
            this.Controls.Add(this.lblAirTemp);
            this.Controls.Add(this.lblTrackTemp);
            this.Controls.Add(this.lblTrackName);
            this.Name = "Stint";
            this.Text = "Stint Detail";
            this.Load += new System.EventHandler(this.stint_view_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblTrackName;
        private Label lblTrackTemp;
        private Label lblAirTemp;
        private Label lblCarName;
        private ListView LapsView;
        private ColumnHeader Lap;
        private ColumnHeader laptime;
        private ColumnHeader fuelrem;
        private ColumnHeader fuelusage;
        private ColumnHeader lapsrem;
        private ColumnHeader topspeed;
        private Label lblTime;
        private Label lblFastest;
    }
}